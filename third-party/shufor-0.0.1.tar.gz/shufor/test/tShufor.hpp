/**@author $username$ <$usermail$>
 * @date $date$*/

#include <shufor.h>
#include <algorithm>

using namespace shufor;

class TestShufor : public ::testing::Test
{
protected:
	void SetUp() {}
	void TearDown() {}
	const TSize size = 10000;
	const TSize splitno = (size*2)/3;
};

TEST_F(TestShufor, GetNext)
{
	TSize seed = (TSize)time(NULL);
	Shufor shf(size, seed);
	std::vector<TSize> data;
	for (TSize i = 0; i < size; ++i)
		data.push_back(shf.GetNext());
	std::sort(data.begin(), data.end());
	data.erase( unique( data.begin(), data.end() ), data.end() );
	ASSERT_EQ(size, data.size());
	for (TSize i = 1; i <= size; ++i )
		ASSERT_EQ(i, data[i-1]);
}

TEST_F(TestShufor, RestoreVal)
{
	TSize seed = (TSize)time(NULL);
	Shufor shf(size, seed);
	std::vector<TSize> data;
	for (TSize i = 0; i < size; ++i)
		data.push_back(shf.GetNext());
	std::vector<TSize> restored_data;
	shf.RestoreVal(seed, size, data[splitno]);
	for (TSize i = 0; i < size - splitno; ++i)
		restored_data.push_back(shf.GetNext());
	ASSERT_EQ(size - splitno, restored_data.size());
	for (TSize i = 0; i < size-splitno; ++i )
		ASSERT_EQ(data[i+splitno], restored_data[i]);
}

TEST_F(TestShufor, RestoreCnt)
{
	TSize seed = (TSize)time(NULL);
	Shufor shf(size, seed);
	std::vector<TSize> data;
	for (TSize i = 0; i < size; ++i)
		data.push_back(shf.GetNext());
	std::vector<TSize> restored_data;
	shf.RestoreCnt(seed, size, splitno);
	for (TSize i = 0; i < size - splitno; ++i)
		restored_data.push_back(shf.GetNext());
	ASSERT_EQ(size - splitno, restored_data.size());
	for (TSize i = 0; i < size-splitno; ++i )
		ASSERT_EQ(data[i+splitno], restored_data[i]);
}

