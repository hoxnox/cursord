/**@author $username$ <$usermail$>
 * @date $date$*/

#include <shufor.h>
#include <algorithm>
#include <iostream>

using namespace shufor;


class TestShuforV : public ::testing::Test
{
protected:
	TestShuforV()
	{
		for(auto i : sizes)
			totalsz *= i;
		splitno = (totalsz*2)/3;
	}
	void SetUp() {}
	void TearDown() {}
	const std::vector<TSize> sizes = {10, 50, 100};
	TSize totalsz = 1;
	TSize splitno = 0;
};

struct Triplet
{
public:
	Triplet(TSize v1, TSize v2, TSize v3)
		: v1(v1), v2(v2), v3(v3)
	{}
	bool operator==(const Triplet& rhv) const
	{
		if (v1 == rhv.v1
		 && v2 == rhv.v2
		 && v3 == rhv.v3)
		{
			return true;
		}
		return false;
	}
	bool operator<(const Triplet& rhv) const
	{
		if (v1 < rhv.v1)
			return true;
		if (v1 == rhv.v1 && v2 < rhv.v2)
			return true;
		if (v1 == rhv.v1 && v2 == rhv.v2 && v3 < rhv.v3)
			return true;
		return false;
	}
	TSize v1;
	TSize v2;
	TSize v3;
};

namespace std {

ostream&
operator<<(ostream& os, const Triplet& v)
{
	os << "(" << v.v1 << ", " << v.v2 << ", " << v.v3 << ")";
	return os;
}

}

TEST_F(TestShuforV, GetNext)
{
	TSize seed = (TSize)time(NULL);
	ShuforV shf(sizes, seed);
	std::vector<Triplet> data;
	for (TSize i = 0; i < totalsz; ++i)
	{
		std::vector<TSize> rs = shf.GetNext();
		ASSERT_EQ(3, rs.size());
		data.emplace_back(Triplet(rs[0], rs[1], rs[2]));
	}
	std::sort(data.begin(), data.end());
	data.erase( unique( data.begin(), data.end() ), data.end() );
	ASSERT_EQ(totalsz, data.size());
	TSize counter_v1 = 1;
	TSize counter_v2 = 1;
	TSize counter_v3 = 1;
	TSize counter_total = 0;
	for (TSize i = 0; i < sizes[0]; ++i )
	{
		for (TSize j = 0; j < sizes[1]; ++j) 
		{
			for (TSize k = 0; k < sizes[2]; ++k)
			{
				ASSERT_EQ(Triplet(counter_v1, counter_v2, counter_v3), data[counter_total]);
				++counter_v3;
				++counter_total;
			}
			counter_v3 = 1;
			++counter_v2;
		}
		counter_v2 = 1;
		++counter_v1;
	}
}

#ifdef COMMENTED

TEST_F(TestShufor, RestoreVal)
{
	TSize seed = (TSize)time(NULL);
	Shufor shf(size, seed);
	std::vector<TSize> data;
	for (TSize i = 0; i < size; ++i)
		data.push_back(shf.GetNext());
	std::vector<TSize> restored_data;
	shf.RestoreVal(seed, size, data[splitno]);
	for (TSize i = 0; i < size - splitno; ++i)
		restored_data.push_back(shf.GetNext());
	ASSERT_EQ(size - splitno, restored_data.size());
	for (TSize i = 0; i < size-splitno; ++i )
		ASSERT_EQ(data[i+splitno], restored_data[i]);
}

TEST_F(TestShufor, RestoreCnt)
{
	TSize seed = (TSize)time(NULL);
	Shufor shf(size, seed);
	std::vector<TSize> data;
	for (TSize i = 0; i < size; ++i)
		data.push_back(shf.GetNext());
	std::vector<TSize> restored_data;
	shf.RestoreCnt(seed, size, splitno);
	for (TSize i = 0; i < size - splitno; ++i)
		restored_data.push_back(shf.GetNext());
	ASSERT_EQ(size - splitno, restored_data.size());
	for (TSize i = 0; i < size-splitno; ++i )
		ASSERT_EQ(data[i+splitno], restored_data[i]);
}

#endif

