﻿////////////////////////////////////////////////////////////////////////
// index.h
// Author: $username$ <$usermail$>
////////////////////////////////////////////////////////////////////////

/**

@image html main_logo.png
@author $username$ <$usermail$>
@date $date$

@mainpage shufor

@tableofcontents

@section intro Введение

@subsection desc Детальное описание

@li @subpage pagename

*/
