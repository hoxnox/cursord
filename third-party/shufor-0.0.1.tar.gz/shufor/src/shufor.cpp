/**@author $username$ <$usermail$>
 * @date $date$*/

#include <shufor.h>
#include <time.h>
#include <cmath>

namespace shufor {

class ShuforImpl
{
public:
	~ShuforImpl() {}
private:
	ShuforImpl(TSize size, TSize seed = 1);
	void init(TSize size, TSize seed = 1);
	TSize doGetNext();
	static const uint16_t prime_poly[64];
	uint8_t pow2_approx_;
	TSize size_;
	TSize count_;
	TSize register_;
	TSize initial_;
	bool  is_cycle_;

friend class Shufor;
};

bool
Shufor::IsCycle() const
{
	return impl_->is_cycle_;
}

const uint16_t ShuforImpl::prime_poly[64] = {
	   1, // 00000001
	   3, // 00000011
	   3, // 00000011
	   3, // 00000011
	   5, // 00000101
	   3, // 00000011
	   3, // 00000011
	  29, // 00011101
	  17, // 00010001
	   9, // 00001001
	   5, // 00000101
	  83, // 01010011
	  27, // 00011011
	  43, // 00101011
	   3, // 00000011
	  45, // 00101101
	   9, // 00001001
	 129, // 10000001
	  39, // 00100111
	   9, // 00001001
	   5, // 00000101
	   3, // 00000011
	  33, // 00100001
	  27, // 00011011
	   9, // 00001001
	  71, // 01000111
	  39, // 00100111
	   9, // 00001001
	   5, // 00000101
	  83, // 01010011
	   9, // 00001001
	 197, // 11000101
	8193, // 10000000000001
	 231, // 11100111
	   5, // 00000101
	 119, // 01110111
	  83, // 01010011
	  99, // 01100011
	  17, // 00010001
	  57, // 00111001
	   9, // 00001001
	 153, // 10011001
	  89, // 01011001
	 101, // 01100101
	  27, // 00011011
	 449, // 111000001
	  33, // 00100001
	 183, // 10110111
	 113, // 01110001
	  29, // 00011101
	  75, // 01001011
	   9, // 00001001
	  71, // 01000111
	 125, // 01111101
	  71, // 01000111
	 149, // 10010101
	 129, // 10000001
	  99, // 01100011
	 123, // 01111011
	   3, // 00000011
	  39, // 00100111
	 105, // 01101001
	   3, // 00000011
	  27  // 00011011
};

inline TSize crop(TSize num, uint8_t pow2)
{
	if(pow2 >= sizeof(TSize)*8)
		return num;
	TSize mask = 0xffffffffffffffffUL;
	mask <<= pow2;
	mask = ~mask;
	return num & mask;
}

inline uint16_t get_pow2_approx(TSize val)
{
	uint8_t pow2_approx = 0;
	if(val > 9223372036854775808UL)
	{
		pow2_approx = 63;
	}
	else
	{
		while(pow2_approx < 64)
		{
			if(val >= (1 << (pow2_approx + 1)))
				++pow2_approx;
			else
				break;
		}
	}
	return pow2_approx;
}

void
ShuforImpl::init(TSize size, TSize seed /*= 0*/)
{
	pow2_approx_ = 0;
	register_ = 1;
	initial_ = 1;
	is_cycle_ = false;
	if (size == 0)
		return;
	size_ = size;
	pow2_approx_ = get_pow2_approx(size);
	register_ = seed == 0 ? 1 : seed;
	register_ = crop(register_, pow2_approx_ + 1);
	if (register_ > size)
		doGetNext();
	initial_ = register_;
}

ShuforImpl::ShuforImpl(TSize size, TSize seed  /*= 0*/)
	: pow2_approx_(0)
	, register_(1)
	, initial_(1)
	, is_cycle_(false)
{
	init(size, seed);
}

Shufor::Shufor(TSize size, TSize seed)
	: impl_(new ShuforImpl(size, seed))
{
}

/*@brief Get next number*/
TSize
ShuforImpl::doGetNext()
{
	TSize result = register_;
	do{
		if(register_ & 0x0000000000000001UL)
			register_ = ((register_ ^ prime_poly[pow2_approx_ ]) >> 1) | (1 << pow2_approx_);
		else
			register_ >>= 1;
	}while(register_ > size_);
	if(register_ == initial_)
		is_cycle_ = true;
	return result;
}

/*@brief Get next number*/
TSize
Shufor::GetNext()
{
	return impl_->doGetNext();
}

/*@brief Restore ShuffleGenerator to previous state, using last
 * generated value
 * @param size - total size of shuffled set
 * @param val - value to restore*/
void Shufor::RestoreVal(TSize seed, TSize size, TSize val)
{
	impl_->init(size, seed);
	impl_->register_ = val;
}

/*@brief Restore ShuffleGenerator to previous state, usend count
 * of number generated*/
void Shufor::RestoreCnt(TSize seed, TSize size, TSize count)
{
	if(size < count)
		return;
	impl_->init(size, seed);
	for(TSize i = 0; i < count; ++i)
		GetNext();
}

TSize
ShuforV::init(const std::vector<TSize>& sizes)
{
	uint8_t total_pow2 = 0;
	for (auto i : sizes)
	{
		uint8_t pow2 = get_pow2_approx(i);
		total_pow2 += pow2 + 1;
		if (total_pow2 > 64)
		{
			total_pow2 = 64;
			return 0;
		}
		bitcnt_.push_back(pow2+1);
	}
	return total_pow2;
}

ShuforV::ShuforV(const std::vector<TSize>& sizes, TSize seed)
	: sizes_(sizes)
{
	shf_.reset(new Shufor(pow(2, init(sizes)), seed));
}

std::vector<TSize>
ShuforV::GetNext()
{
	std::vector<TSize> rs;
	while(!shf_->IsCycle())
	{
		TSize val = shf_->GetNext();
		{
			uint8_t bitsdone = 0;
			bool allgood = true;
			rs.clear();
			for (size_t i = 0; i < sizes_.size(); ++i)
			{
				TSize cur = (val>>bitsdone)%(1<<bitcnt_[i]);
				{
					if (cur > sizes_[i] || cur == 0)
					{
						allgood = false;
						break;
					}
					rs.push_back(cur);
				}
				bitsdone += bitcnt_[i];
			}
			if(allgood)
				break;
		}
	}
	if (rs.size() != sizes_.size())
		return std::vector<TSize>();
	return rs;
}

void
ShuforV::RestoreVal(const TSize seed, const std::vector<TSize>& sizes, const std::vector<TSize>& val)
{
	TSize commonsz = init(sizes);
	shf_.reset(new Shufor(pow(2, commonsz), seed));
	TSize cmmval = 0;
	for (size_t i = 0; i < bitcnt_.size(); ++i)
		cmmval += val[i]*(1<<bitcnt_[i]);
	shf_->RestoreVal(seed, commonsz, cmmval);
}

void
ShuforV::RestoreCnt(const TSize seed, const std::vector<TSize>& sizes, const TSize count)
{
	shf_.reset(new Shufor(pow(2, init(sizes)), seed));
	for(TSize i = 0; i < count; ++i)
		GetNext();
}

} // namespace

