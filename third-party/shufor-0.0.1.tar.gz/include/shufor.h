/**@author $username$ <$usermail$>
 * @date $date$
 *
 * Shuffle generator.*/

#pragma once
#include <stdint.h>
#include <memory>
#include <vector>
#include <cstring>

// TODO: with help of gmp add support for TSize > 2^32

namespace shufor {

class ShuforImpl;
typedef uint64_t TSize;

class Shufor
{
public:
	Shufor(TSize size, uint64_t seed = 1);
	TSize GetNext();
	void RestoreVal(TSize seed, TSize size, TSize val);
	void RestoreCnt(TSize seed, TSize size, TSize count);
	bool IsCycle() const;
private:
	std::shared_ptr<ShuforImpl> impl_;
};

class ShuforV
{
public:
	ShuforV(const std::vector<TSize>& sizes, TSize seed = 1);
	std::vector<TSize> GetNext();
	void RestoreVal(const TSize seed, const std::vector<TSize>& sizes, const std::vector<TSize>& val);
	void RestoreCnt(const TSize seed, const std::vector<TSize>& sizes, const TSize count);
	bool IsCycle() const { return shf_->IsCycle(); };
private:
	TSize init(const std::vector<TSize>& sizes);
	std::unique_ptr<Shufor> shf_;
	std::vector<TSize> sizes_;
	std::vector<TSize> bitcnt_;
};

} // namespace

