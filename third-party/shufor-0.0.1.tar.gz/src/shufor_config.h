/* WARNING: FILE shufor_config.h
 *          IS REGENERATED EVERY cmake CONFIGURE STAGE YOU SHOULD USE
 *          FOLLOWING FILES TO MAKE CHANGES:
 *          src/shufor_config.cfg
 *          CMakeLists.txt */

#pragme once

#define shufor_VERSION_MAJOR 0
#define shufor_VERSION_MINOR 0
#define shufor_VERSION_PATCH 1

