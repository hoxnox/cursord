/**@author $username$ <$usermail$>
 * @date $date$
 *
 * @brief shufor test launcher.*/

// Google Testing Framework
#include <gtest/gtest.h>
#include "tShufor.hpp"
#include "tShuforV.hpp"

// test cases

int main(int argc, char *argv[])
{
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}


